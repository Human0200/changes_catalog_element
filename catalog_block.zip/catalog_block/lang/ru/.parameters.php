<?
$MESS["SHOW_RATING"] = "Отображать рейтинг";

$MESS["CP_BCS_TPL_BESTSELLERS"] = "Самые продаваемые";
$MESS["CP_BCS_TPL_PERSONAL"] = "Персональные рекомендации";
$MESS["CP_BCS_TPL_SOLD_WITH"] = "Продаваемые с этим товаром";
$MESS["CP_BCS_TPL_VIEWED_WITH"] = "Просматриваемые с этим товаром";
$MESS["CP_BCS_TPL_SIMILAR"] = "Похожие товары";
$MESS["CP_BCS_TPL_SIMILAR_ANY"] = "Продаваемые/Просматриваемые/Похожие товары";
$MESS["CP_BCS_TPL_PERSONAL_WBEST"] = "Самые продаваемые/Персональные";
$MESS["CP_BCS_TPL_RAND"] = "Любая рекомендация";
$MESS["CP_BCS_TPL_TYPE_TITLE"] = "Тип рекомендации";
$MESS["CP_BCS_TPL_PRODUCT_ID_PARAM"] = "Параметр ID продукта (для товарных рекомендаций)";
$MESS["CP_BCS_TPL_SHOW_FROM_SECTION"] = "Показывать товары из раздела";
